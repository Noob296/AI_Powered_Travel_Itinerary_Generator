# === app.py ===
from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import requests
import re
import json
import os
from datetime import datetime
from markupsafe import Markup
from markdown import markdown as md_to_html

# === Flask App Setup ===
app = Flask(__name__)
# Use environment variable for secret key, with a fallback for development
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev_secret_key")

# === Database Setup ===
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///travel_planner.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config['SESSION_PERMANENT'] = False # Sessions are not permanent

# === API Keys ===
# IMPORTANT: It is generally recommended to load API keys from environment variables
# for security reasons, rather than hardcoding them directly in the code.
# For example:
# GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY")
# GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
GOOGLE_API_KEY = "Put your google api key"
GEMINI_API_KEY = "Put your gemnini api key"
# Construct the Gemini API URL
GEMINI_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_API_KEY}"

# === Init DB ===
db = SQLAlchemy(app)

# === Jinja Filter ===
# Custom Jinja filter to render Markdown content as HTML
@app.template_filter('markdown')
def markdown_filter(text):
    return Markup(md_to_html(text)) if text else ""

# === Models ===
# User model for database, storing username, password, and linking to chats
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    # Relationship to Chat model, cascading deletes
    chats = db.relationship('Chat', backref='user', lazy=True, cascade="all, delete-orphan")

# Chat model for database, storing messages, responses, timestamps, and user ID
class Chat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text) # Store the AI's response
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

# === Utility Functions ===

# Helper function to extract JSON object from a given text
def extract_json_from_text(text):
    try:
        # Use regex to find the first JSON-like object
        match = re.search(r"\{[\s\S]*?\}", text)
        if match:
            return json.loads(match.group())
    except Exception as e:
        print("❌ JSON parsing error:", e)
    return None

# Extracts source and destination from user input using Gemini API
def extract_source_destination(user_input):
    system_prompt = """
    Extract only the source (starting city) and destination (target city) from the following unstructured travel query.
    If a source or destination cannot be confidently identified as a city, return an empty string for that field.

    Return your response in the following JSON format:
    {
      "source": "...",
      "destination": "..."
    }

    Here is the user's input:
    """
    payload = {
        "contents": [
            {"parts": [{"text": system_prompt + "\n" + user_input}]}
        ]
    }
    headers = {"Content-Type": "application/json"}
    try:
        # Make a POST request to the Gemini API
        response = requests.post(GEMINI_URL, headers=headers, json=payload, timeout=60)
        response.raise_for_status() # Raise an HTTPError for bad responses (4xx or 5xx)

        data = response.json()
        # Extract the text content from the Gemini response
        text_output = data["candidates"][0]["content"]["parts"][0]["text"]
        # Parse the extracted text as JSON
        structured = extract_json_from_text(text_output)
        # Return source and destination if successfully extracted
        if structured and "source" in structured and "destination" in structured:
            return structured["source"].strip(), structured["destination"].strip()
    except requests.exceptions.RequestException as e:
        print(f"❌ Gemini request failed: {e}")
    except (KeyError, IndexError, TypeError) as e:
        print(f"❌ Gemini response parsing error: {e}")
    return "", "" # Return empty strings if extraction fails

# Fetches geographical coordinates for a given city using Google Geocoding API
def get_coordinates(city):
    if not city: # Handle empty city input
        return None
    try:
        url = f"https://maps.googleapis.com/maps/api/geocode/json?address={city}&key={GOOGLE_API_KEY}"
        res = requests.get(url, timeout=10)
        res.raise_for_status()
        json_data = res.json()
        if json_data['status'] == 'OK' and json_data['results']:
            loc = json_data['results'][0]['geometry']['location']
            return f"{loc['lat']},{loc['lng']}"
        else:
            return None # No results or status not OK
    except Exception as e:
        print(f"❌ Error getting coordinates for {city}: {e}")
        return None

# Fetches nearby places of a specific type using Google Places API
def get_places(location, place_type):
    try:
        url = f"https://maps.googleapis.com/maps/api/place/nearbysearch/json?location={location}&radius=5000&type={place_type}&key={GOOGLE_API_KEY}"
        res = requests.get(url, timeout=10)
        res.raise_for_status()
        results = res.json().get("results", [])
        # Format the results for display
        return [f"- {p.get('name')} (Rating: {p.get('rating', 'N/A')}) - {p.get('vicinity')}" for p in results]
    except Exception as e:
        print(f"❌ Error getting places of type {place_type} at {location}: {e}")
        return []

# Aggregates places information (attractions, hotels, restaurants) for a city
def get_city_places(city):
    loc = get_coordinates(city)
    if not loc:
        return f"No location found for {city}."
    
    out = [f"\n📍 Attractions in {city}:"]
    # Add tourist attractions
    out.extend(get_places(loc, "tourist_attraction"))
    out.extend(get_places(loc, "museum"))
    out.extend(get_places(loc, "art_gallery"))
    out.extend(get_places(loc, "park"))
    
    out.append(f"\n🏨 Hotels:")
    # Add lodging options
    out.extend(get_places(loc, "lodging"))
    
    out.append(f"\n🍽️ Restaurants:")
    # Add restaurant options
    out.extend(get_places(loc, "restaurant"))
    
    return "\n".join(out)

# Fetches travel distance and duration between two locations using Google Distance Matrix API
def get_travel_info(src, dst):
    try:
        url = f"https://maps.googleapis.com/maps/api/distancematrix/json?origins={src}&destinations={dst}&key={GOOGLE_API_KEY}"
        res = requests.get(url, timeout=10)
        res.raise_for_status()
        data = res.json()['rows'][0]['elements'][0]
        # Return formatted distance and duration
        return f"Distance: {data['distance']['text']}, Duration: {data['duration']['text']}"
    except Exception as e:
        print(f"❌ Error getting travel info from {src} to {dst}: {e}")
        return "No travel data available."

# Generates a travel itinerary using Gemini API based on extracted info
def generate_itinerary(user_input, travel_data, places_info, source, destination):
    prompt = f"""
    User Request:
    \"\"\"{user_input}\"\"\"

    Travel Info:
    {travel_data}

    Destination Details:
    {places_info}

    You are a highly detailed and engaging travel expert AI. Your task is to generate a comprehensive travel itinerary.

    Here are the strict formatting and content requirements:

    1.  **Overall Tone**: Be enthusiastic, informative, and helpful.
    2.  **Introduction**: Start with a welcoming and exciting opening.
    3.  **Travel to Destination**:
        * Recommend the best mode of travel **from {source.title()} to {destination.title()}**, considering the user's input (if any, like budget/preference).
        * Include approximate travel time.
        * If specific flight/train information is available from the user's query or a logical inference, you can mention general options (e.g., "early morning flight," "overnight train").
    4.  **Accommodation**:
        * Choose specific hotels from the "Destination Details" provided.
        * For each hotel, include: **Name, Rating, and Vicinity/Address**.
        * Suggest an approximate price range based on the user's budget (if mentioned).
    5.  **Daily Itinerary (Most Important)**:
        * Break down each day with specific activities.
        * For each activity, include:
            * **Approximate Time Slot**: (e.g., "9:00 AM - 12:00 PM:").
            * **Activity Name**: (e.g., "Visit India Gate").
            * **Detailed Description**: Provide 2-3 sentences of engaging and informative description for each major point of interest (history, significance, what to expect).
            * **Associated Place (Hotel/Restaurant/Attraction)**: If an activity involves a place from "Destination Details", specify its **Name, Rating, and Vicinity/Address** if available from the `places_info`. Do NOT invent links or addresses if not provided.
            * **Local Transport**: Suggest how to get there (e.g., "Take a short auto-rickshaw ride," "Metro to Rajiv Chowk").
        * Include recommendations for **meals (breakfast, lunch, dinner)**, selecting specific restaurants from the "Destination Details" with their **Name, Rating, and Vicinity/Address**.
        * Include a variety of attractions: historical, cultural, recreational, shopping, etc.
        * Ensure the itinerary makes logistical sense for daily travel.
    6.  **Budget Breakdown**: Provide a clear, itemized approximate budget breakdown.
    7.  **Important Tips**: Offer practical advice (e.g., local transport, food, safety, weather).
    8.  **Return Journey**: Clearly state how the user returns to {source.title()}.
    9.  **Formatting**:
        * Use **Markdown** throughout for clear headings, lists, and bold text.
        * Use **emojis** sparingly to enhance engagement.
        * Ensure the response is well-structured and easy to read.
    """
    payload = {
        "contents": [
            {"parts": [{"text": prompt}]}
        ]
    }
    headers = {"Content-Type": "application/json"}
    try:
        # Make a POST request to the Gemini API for itinerary generation
        res = requests.post(GEMINI_URL, headers=headers, json=payload, timeout=120)
        res.raise_for_status()
        return res.json()["candidates"][0]["content"]["parts"][0]["text"]
    except requests.exceptions.RequestException as e:
        print(f"❌ Gemini itinerary generation failed: {e}")
        return "❌ Failed to generate itinerary."
    except (KeyError, IndexError, TypeError) as e:
        print(f"❌ Gemini response parsing error for itinerary: {e}")
        return "❌ Failed to generate itinerary."

# === Routes ===

# Home route, redirects to chat if logged in, otherwise shows welcome page
@app.route("/")
def index():
    # Re-added session.clear() to ensure a clean session for initial app access
    # This directs new or logged-out users to the welcome/signin page.
    session.clear() 
    return redirect(url_for("chat")) if "user_id" in session else render_template("welcome.html")

# Chat route, requires login
@app.route("/chat")
def chat():
    if "user_id" not in session:
        return redirect(url_for("signin"))
    # Removed session.pop("current_trip_details", None) to preserve any session data
    return render_template("index.html")

# Route to generate travel itinerary based on user input
@app.route("/generate", methods=["POST"])
def generate():
    if "user_id" not in session:
        return jsonify({"response": "Please log in."}), 401

    user_input = request.json.get("message")
    if not user_input:
        return jsonify({"response": "No message provided."}), 400

    # Directly extract source and destination from the user input
    source, destination = extract_source_destination(user_input)

    # Validate if the extracted source and destination are actual recognizable locations
    source_coords = get_coordinates(source)
    destination_coords = get_coordinates(destination)

    response_message = ""
    if not source_coords and not destination_coords:
        response_message = "❌ I couldn't recognize either your source or destination. Please provide valid city names for both (e.g., 'Plan a trip from London to Paris')."
    elif not source_coords:
        response_message = f"❌ I couldn't recognize '{source}' as a valid source city. Please provide a valid source city name."
    elif not destination_coords:
        response_message = f"❌ I couldn't recognize '{destination}' as a valid destination city. Please provide a valid destination city name."

    if response_message:
        db.session.add(Chat(user_id=session["user_id"], message=user_input, response=response_message))
        db.session.commit()
        return jsonify({"response": response_message})

    # Fetch travel information and places
    travel_data = get_travel_info(source, destination)
    places_info = get_city_places(destination)
    
    # Generate the itinerary
    itinerary = generate_itinerary(user_input, travel_data, places_info, source, destination)
    
    # Store the user message and AI response in the database
    db.session.add(Chat(user_id=session["user_id"], message=user_input, response=itinerary))
    db.session.commit()
    
    return jsonify({"response": itinerary})

# Signup route for new user registration
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username, password = request.form["username"], request.form["password"]
        # Check if user already exists
        if User.query.filter_by(username=username).first():
            return render_template("signup.html", error="User already exists.")
        # Create new user and add to database
        db.session.add(User(username=username, password=password))
        db.session.commit()
        return redirect(url_for("signin"))
    return render_template("signup.html")

# Signin route for existing user login
@app.route("/signin", methods=["GET", "POST"])
def signin():
    if request.method == "POST":
        user = User.query.filter_by(username=request.form["username"], password=request.form["password"]).first()
        if user:
            # Set session variables on successful login
            session["user_id"] = user.id
            session["username"] = user.username
            return redirect(url_for("chat"))
        return render_template("signin.html", error="Invalid credentials.")
    return render_template("signin.html")

# Logout route, clears session
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

# History route, displays user's chat history
@app.route("/history")
def history():
    if "user_id" not in session:
        return redirect(url_for("signin"))
    user = db.session.get(User, session["user_id"])
    if not user:
        # If user not found, clear session and redirect to signin
        session.clear()
        return redirect(url_for("signin"))
    return render_template("history.html", chats=user.chats)

# Main entry point for running the Flask app
if __name__ == "__main__":
    with app.app_context():
        db.create_all() # Create database tables if they don't exist
    #app.run(debug=True, port=5001) # Run the app in debug mode on port 5001
    app.run(host='0.0.0.0', port=5000, debug=True)
